<template>
  <div>
    Content
  </div>
</template>

<script lang="ts" setup>

</script>

<style scoped lang="scss">
@use "~/assets/scss/_tokens.scss" as *;

</style>
