<template>
    <div class="omni-board d-flex gap-3" id="tasks">
        <!-- DnD de COLUNAS -->
        <draggable v-model="columnsLocal" item-key="id" class="d-flex gap-3" :group="{ name: 'columns' }"
            :animation="150" :filter="'.dnd-ignore'" :preventOnFilter="false" @change="onColumnsChange">
            <!-- ✅ OBRIGATÓRIO: slot item -->
            <template #item="{ element: col }">
                <div class="omni-board-column-wrapper">
                    <div class="omni-board-header p-2 fw-bold d-flex align-items-center gap-2">
                        <template v-if="editingId === col.id">
                            <input v-model.trim="renameBuffer" class="form-control form-control-sm dnd-ignore"
                                style="max-width: 220px" @keydown.enter.prevent="confirmRename(col)"
                                @keydown.esc.prevent="cancelRename()" @blur="confirmRename(col)" autofocus />
                        </template>

                        <template v-else>
                            <span class="badge bg-success-subtle text-success-emphasis">{{ col.name }}</span>
                            <span class="text-muted small">{{ countTasks(col.id) }}</span>

                            <!-- Nova tarefa -->
                            <NxButton class="ms-auto" size="sm" variant="outline" tone="primary" icon="plus" iconOnly
                                title="Nova tarefa" @click="emitCreate(col.id)" />

                            <!-- Menu da coluna -->
                            <NxButton class="dnd-ignore" size="sm" variant="outline" tone="neutral" icon="more-vertical"
                                iconOnly title="Opções da coluna" dropdown dropdownType="menu" placement="bottom-end">
                                <template #menu>
                                    <div class="d-flex flex-column gap-1" style="min-width: 180px">
                                        <button class="btn btn-sm btn-light text-start dnd-ignore"
                                            @click.stop="startRename(col)">
                                            Renomear
                                        </button>
                                        <button class="btn btn-sm btn-danger text-start dnd-ignore"
                                            @click.stop="confirmDeleteColumn(col.id)">
                                            Excluir coluna
                                        </button>
                                        <!-- dentro do #menu da coluna -->
                                        <button class="btn btn-sm btn-light text-start"
                                            @click.stop="confirmDelete('move', col.id)">
                                            Mover páginas e excluir grupo…
                                        </button>

                                        <button class="btn btn-sm btn-danger text-start"
                                            @click.stop="confirmDelete('cascade', col.id)">
                                            Excluir grupo e páginas…
                                        </button>

                                    </div>
                                </template>
                            </NxButton>
                        </template>
                    </div>

                    <BoardColumn :column="{ id: col.id, name: col.name }" :tasks="tasksByColumn(col.id)"
                        :all-columns="columns" @update="onUpdate" @remove="onRemove" @toggle-archive="onToggleArchive"
                        @reorder-tasks="onTasksReordered" @move-task="onTaskMoved" />
                </div>
            </template>
        </draggable>

        <!-- Botão final -->
        <NxButton variant="outline" tone="neutral" class="align-self-start" @click="createColumn">+ Novo grupo
        </NxButton>


        <!-- Monta o toast center uma vez na página -->
        <ToastCenter ref="toastRef" />

    </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { ref, watch, toRaw, isProxy } from 'vue'
import draggable from 'vuedraggable'
import NxButton from '@/components/buttons/NxButton.vue'
import BoardColumn from '@/components/board/BoardColumn.vue'
import ToastCenter from '@/components/ToastCenter.vue'
import { useTasksStore } from '@/stores/tasks'
import { useColumnsStore } from '@/stores/columns'

type Task = any

const tasksStore = useTasksStore()
const columnsStore = useColumnsStore()
const { list: tasks } = storeToRefs(tasksStore)
const { items: columns } = storeToRefs(columnsStore)

/* contador por coluna */
function countTasks(columnId: number) {
    return tasks.value.filter(t => ((t as any).column_id ?? t.column?.id ?? 0) === columnId).length
}

/* lista local para o draggable */
const columnsLocal = ref<any[]>([])
watch(
    columns,
    (v) => { columnsLocal.value = JSON.parse(JSON.stringify(v)) },
    { immediate: true, deep: true }
)

function onColumnsChange() {
    // aplica ordenação no store (otimista)
    columnsStore.reorderLocal(columnsLocal.value)
}

/* criar coluna — otimista */
async function createColumn() {
    await columnsStore.createOptimistic('Novo grupo')
}

/* tasks por coluna (ordenadas) */
function tasksByColumn(columnId: number) {
    return tasks.value
        .filter(t => ((t as any).column_id ?? t.column?.id ?? 0) === columnId)
        .sort((a: any, b: any) => (a.order_position ?? 0) - (b.order_position ?? 0))
}

function cloneSafe<T>(x: T): T {
    const raw = isProxy(x) ? toRaw(x) : x
    return JSON.parse(JSON.stringify(raw))
}

/* criar task (otimista via store) */
function emitCreate(columnId: number) {
    tasksStore.createOptimistic({
        name: 'Nova tarefa',
        column_id: columnId,
        description: null,
        priority: '',
        due_date: null
    })
}

/* atualizações de task (mantido) */
async function onUpdate({ id, patch }: { id: number; patch: Record<string, any> }) {
    const idx = tasks.value.findIndex(t => t.id === id)
    if (idx === -1) return
    const prev = cloneSafe(tasks.value[idx])
    Object.assign(tasks.value[idx], patch)
    if ('column_id' in patch) {
        ; (tasks.value[idx] as any).column_id = patch.column_id
        const newCol = columnsStore.byId(patch.column_id)
        tasks.value[idx].column = newCol ?? (tasks.value[idx].column ?? { id: patch.column_id, name: '—', project_id: 2 })
        if (newCol) {
            tasks.value[idx].column.name = newCol.name
            tasks.value[idx].column.project_id = newCol.project_id
        }
    }
    try {
        await $fetch(`/api/admin/tasks/${id}`, { method: 'PUT', body: { ...patch, project_id: 2 } })
    } catch {
        tasks.value[idx] = prev
    }
}

async function onRemove(id: number) {
    await tasksStore.removeOptimistic(id)
}

async function onToggleArchive(_task: any) { }

/* DnD tasks (usa helpers do store) */
async function onTasksReordered(payload: { columnId: number; orderedIds: number[] }) {
    tasksStore.applyLocalReorder(payload.columnId, payload.orderedIds)
}
async function onTaskMoved(payload: {
    taskId: number
    fromColumnId: number
    toColumnId: number
    toIndex: number
    orderedIdsInSource: number[]
    orderedIdsInTarget: number[]
}) {
    tasksStore.applyLocalMove(
        payload.taskId,
        payload.toColumnId,
        payload.toIndex,
        payload.orderedIdsInTarget,
        payload.fromColumnId
    )
}

/* rename (ESC cancela) */
const editingId = ref<number | null>(null)
const renameBuffer = ref('')
let previousName = ''

function startRename(col: any) {
    editingId.value = col.id
    renameBuffer.value = col.name
    previousName = col.name
}
function cancelRename() {
    editingId.value = null
    renameBuffer.value = previousName
}
async function confirmRename(col: any) {
    const name = renameBuffer.value?.trim()
    const original = previousName
    editingId.value = null
    if (!name || name === original) return
    await columnsStore.renameOptimistic(col.id, name)
}
async function confirmDeleteColumn(id: number) {
    await columnsStore.removeOptimistic(id)
}

const toastRef = ref<InstanceType<typeof ToastCenter> | null>(null)
function confirmDelete(mode: 'move' | 'cascade', columnId: number) {
    toastRef.value?.openConfirm(mode, columnId)
}
</script>

<style scoped>
.omni-board-column-wrapper {
    min-width: 280px;
}

.btn-board-icon {
    padding: 0.25rem 0.5rem;
}
</style>
