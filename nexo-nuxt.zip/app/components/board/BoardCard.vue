<template>
    <div class="board-card card" :class="{ 'archived-task hidden': archived }" :data-task-id="task.id"
        :data-archived="archived ? 1 : 0" :data-user-id="task.user_id || ''" :data-client-id="task.client_id || ''"
        :data-type-id="task.type || task.type_id || ''" :data-title="task.name" :data-desc="task.description || ''"
        :data-comment="task.comment || ''" :data-start-date="task.start_date || ''" :data-due-date="task.due_date || ''"
        :data-status="columnName" :data-priority="priorityLabel" :data-file-name="task.file_name || ''">
        <!-- HEADER (somente aparência nos controles extras) -->
        <div class="card-header">
            <div class="timer-controls mt-2" :data-task-id="task.id">
                <button class="btn btn-timer play btn-board" data-action="1" title="Iniciar">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                        fill="currentColor">
                        <path d="M8 5v14l11-7z" />
                    </svg>
                </button>
                <button class="btn btn-timer pause btn-board" data-action="2" title="Pausar">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                        fill="currentColor">
                        <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
                    </svg>
                </button>
                <button class="btn btn-timer stop btn-board" data-action="4" title="Parar">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                        fill="currentColor">
                        <path d="M6 6h12v12H6z" />
                    </svg>
                </button>
                <span class="elapsed ms-2" :id="`timer-${task.id}`" style="display:none">00:00:00</span>
            </div>

            <div class="buttons-box d-flex">
                <NxButton class="btn-board btn-delete" size="sm" variant="outline" tone="danger" icon="trash-2" iconOnly
                    title="Excluir" @click="$emit('remove')" />


                <NxButton class="btn-board btn-archive" size="sm" variant="outline" tone="danger" icon="archive"
                    iconOnly title="Excluir" @click="$emit('toggle-archive')" />

                    <!-- ARCHIVE / UNARCHIVE (só aparência; se quiser, ligue ao @toggle-archive)
                    <button class="btn btn-archive btn-board" :title="archived ? 'Desarquivar' : 'Arquivar'"
                        @click="$emit('toggle-archive')">
                        <svg v-if="!archived" xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                            fill="currentColor" viewBox="0 -960 960 960">
                            <path
                                d="M280-160q-33 0-56.5-23.5T200-240v-400h560v400q0 33-23.5 56.5T680-160H280Zm200-200h80v-120h120l-160-160-160 160h120v120Zm-240-360v-80h480v80H240Z" />
                        </svg>
                        <svg v-else xmlns="http://www.w3.org/2000/svg" height="16" width="16" fill="currentColor"
                            viewBox="0 -960 960 960">
                            <path
                                d="M280-160q-33 0-56.5-23.5T200-240v-400h560v400q0 33-23.5 56.5T680-160H280Zm200-240 160-160H520v-200H440v200H280l160 160ZM240-720l40-80h400l40 80H240Z" />
                        </svg>
                    </button>
                     -->
            </div>
        </div>

        <!-- BODY -->
        <div class="card-body">
            <!-- Nome -->
            <div class="board-field" data-column="name">
                <input type="text" class="form-control input-table editable-input" :id="`name-${task.id}`"
                    v-model.trim="local.name" @blur="emitUpdate({ name: local.name })"
                    @keydown.enter.prevent="emitUpdate({ name: local.name })" />
            </div>

            <!-- Linha com (user/client) opcionais -->
            <div class="board-row d-flex">
                <div class="board-field" data-column="user_id" v-if="users?.length">
                    <select class="form-select form-select-sm" v-model="local.user_id"
                        @change="emitUpdate({ user_id: local.user_id })">
                        <option :value="null">Selecionar</option>
                        <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
                    </select>
                </div>
                <div class="board-field" data-column="client_id" v-if="clients?.length">
                    <select class="form-select form-select-sm" v-model="local.client_id"
                        @change="emitUpdate({ client_id: local.client_id })">
                        <option :value="null">Selecionar</option>
                        <option v-for="c in clients" :key="c.id" :value="c.id">{{ c.name }}</option>
                    </select>
                </div>
            </div>

            <!-- Due date -->
            <div class="board-field" data-column="due_date">
                <input type="date" class="form-control input-table editable-input" :id="`due_date-${task.id}`"
                    v-model="local.due_date" @change="emitUpdate({ due_date: local.due_date || null })" />
            </div>

            <!-- Prioridade -->
            <div class="board-field" data-column="priority">
                <select class="form-select form-select-sm" v-model="local.priority"
                    @change="emitUpdate({ priority: local.priority || '' })">
                    <option value="">—</option>
                    <option value="1">Baixa</option>
                    <option value="2">Média</option>
                    <option value="3">Alta</option>
                </select>
            </div>

            <!-- Mover de coluna (opcional: quando allColumns passado) -->
            <div class="board-field" data-column="column_id" v-if="allColumns?.length">
                <select class="form-select form-select-sm" v-model.number="local.column_id"
                    @change="emitUpdate({ column_id: local.column_id })">
                    <option v-for="c in allColumns" :key="c.id" :value="c.id">{{ c.name }}</option>
                </select>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { reactive, watch, computed } from 'vue'
import NxButton from '@/components/buttons/NxButton.vue'

const props = defineProps<{
    task: any
    columnName: string
    allColumns?: Array<{ id: number; name: string }>
    users?: Array<{ id: number; name: string }>
    clients?: Array<{ id: number; name: string }>
}>()

const emit = defineEmits<{
    (e: 'update', patch: Record<string, any>): void
    (e: 'remove'): void
    (e: 'toggle-archive'): void
}>()

const local = reactive({
    name: props.task.name ?? '',
    due_date: props.task.due_date ?? '',
    priority: props.task.priority ?? '',
    column_id: (props.task as any).column_id ?? props.task.column?.id ?? 0,
    user_id: props.task.user_id ?? null,
    client_id: props.task.client_id ?? null
})

watch(
    () => props.task,
    (t: any) => {
        local.name = t?.name ?? ''
        local.due_date = t?.due_date ?? ''
        local.priority = t?.priority ?? ''
        local.column_id = t?.column_id ?? t?.column?.id ?? local.column_id
        local.user_id = t?.user_id ?? null
        local.client_id = t?.client_id ?? null
    },
    { deep: true }
)

function emitUpdate(patch: Record<string, any>) { emit('update', patch) }

const priorityLabel = computed(() => {
    if (local.priority === '1') return 'baixa'
    if (local.priority === '2') return 'média'
    if (local.priority === '3') return 'alta'
    return ''
})

const archived = computed(() => !!(props.task.archived || props.task.is_archived))
const users = computed(() => props.users ?? [])
const clients = computed(() => props.clients ?? [])
const allColumns = computed(() => props.allColumns ?? [])
const columnName = computed(() => props.columnName ?? '')
</script>
