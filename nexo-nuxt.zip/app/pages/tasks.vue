<template>
    <section class="p-1">
        <!-- status de sync/outbox -->
        <div v-if="tasksStore.hasUnsynced" class="small text-warning">
            Sincronizando alterações…
            <button class="btn btn-link btn-sm p-0" @click="tasksStore.retrySync()">Tentar agora</button>
        </div>
        <div v-if="tasksStore.hasErrors" class="small text-danger">
            Algumas tarefas não foram salvas. Vamos tentar novamente automaticamente.
        </div>

        <div class="d-flex align-items-center gap-3 mb-3">
            <h2 class="m-0">Tasks (Board)</h2>
            <button class="btn btn-sm btn-outline-light ms-auto" :disabled="loading" @click="reload">
                Recarregar
            </button>
            <LogoutButton />
        </div>

        <div v-if="errorMsg" class="alert alert-danger py-2 px-3 mb-3">
            {{ errorMsg }}
        </div>

        <ViewBoard />
    </section>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import ViewBoard from '@/components/board/ViewBoard.vue'
import LogoutButton from '@/components/buttons/LogoutButton.vue'
import { useTasksStore } from '@/stores/tasks'
import { useColumnsStore } from '@/stores/columns'

// IMPORTANTE: só 'auth' e 'approved'. Tire o 'hydrate' da page
definePageMeta({ middleware: ['auth', 'approved'] })

const tasksStore = useTasksStore()
const columnsStore = useColumnsStore()

const loading = ref(false)
const errorMsg = computed(() => tasksStore.error || columnsStore.error || null)

onMounted(async () => {
    // 1) hidrata do cache (não chama API aqui)
    await Promise.allSettled([
        tasksStore.hydrateFromCache(),
        // só chama se existir na store de columns
        (columnsStore as any).hydrateFromCache?.()
    ])

    // 2) dispara sync/outbox em background
    tasksStore.processOutbox()

    // 3) agora sim revalida (SWR) após 'auth' ter passado
    reload()
})

async function reload() {
    loading.value = true
    try {
        await Promise.allSettled([
            columnsStore.fetchAll?.(),   // sem cache aqui, só revalidação
            tasksStore.fetchAllAll(),    // tem dedupe
        ])
    } finally {
        loading.value = false
    }
}
</script>
