<template>
    <div>
        <Header></Header>
        <Sidebar></Sidebar>
        <Content>

        </Content>


    </div>
</template>

<script lang="ts" setup>
import Header from '~/components/layout/NxHeader.vue'
import Sidebar from '~/components/layout/NxSidebar.vue'
import Content from '~/components/layout/Content.vue'
</script>

<style></style>