// server/api/admin/tasks/all.get.ts
import { proxyToLaravel } from '../../../utils/proxyLaravel'
import { getQuery, setHeader } from 'h3'

type LaravelPage<T> = {
    data: T[]
    meta?: {
        current_page?: number
        last_page?: number
        per_page?: number | string
        total?: number
    }
}

export default defineEventHandler(async (event) => {
    const q = getQuery(event)
    const cfg = useRuntimeConfig()

    const projectId =
        (q.project_id ? String(q.project_id) : undefined) ??
        (cfg.public?.defaultProjectId ? String(cfg.public.defaultProjectId) : undefined)

    if (!projectId) {
        throw createError({ statusCode: 400, statusMessage: 'project_id é obrigatório' })
    }

    // tenta pegar tudo em 1 chamada
    const PER_PAGE = Number(q.per_page ?? 500) // ajuste se quiser
    const MAX_PAGES = 50                       // trava dura
    const MAX_ITEMS = 10_000                   // trava dura

    let page = 1
    const all: any[] = []
    let lastPageSeen: number | null = null
    const seenFirstItemIds = new Set<number | string>() // para detectar repetição

    while (page <= MAX_PAGES && all.length < MAX_ITEMS) {
        const path = `/api/admin/tasks?page=${page}&per_page=${PER_PAGE}&project_id=${encodeURIComponent(projectId)}`
        const res: any = await proxyToLaravel(event, path)

        // normaliza possíveis formatos
        let items: any[] = []
        let currentPage: number | undefined
        let lastPage: number | undefined

        if (Array.isArray(res)) {
            // backend sem paginação → assume 1 página e sai
            items = res
            currentPage = 1
            lastPage = 1
        } else {
            const body = res as LaravelPage<any> | any
            if (Array.isArray(body?.data?.data)) {
                items = body.data.data
            } else if (Array.isArray(body?.data)) {
                items = body.data
            }

            currentPage = Number(body?.meta?.current_page ?? NaN)
            lastPage = Number(body?.meta?.last_page ?? NaN)
        }

        // se backend ignorar 'page' e ficar repetindo, detecta e dá break
        const firstId = items?.[0]?.id
        if (firstId !== undefined && seenFirstItemIds.has(firstId)) {
            break
        }
        if (firstId !== undefined) seenFirstItemIds.add(firstId)

        if (!items?.length) break

        all.push(...items)

        // sem meta de paginação → assume 1 página e sai
        if (!Number.isFinite(currentPage) || !Number.isFinite(lastPage)) break

        // se repetir o número da página (backend ignorando page) → break
        if (lastPageSeen !== null && currentPage === lastPageSeen) break
        lastPageSeen = currentPage!

        if (currentPage! >= lastPage!) break
        page++
    }

    setHeader(event, 'X-Items-Total', String(all.length))
    setHeader(event, 'X-Project-Id', String(projectId))
    return { data: all }
})
