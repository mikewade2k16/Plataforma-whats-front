// server/api/admin/tasks/batch.post.ts
import { defineEventHandler, readBody } from 'h3'
import { proxyToLaravel } from '../../../utils/proxyLaravel'

type BatchOp =
    | { id: string; type: 'create'; payload: any }
    | { id: string; type: 'update'; payload: { id: number; patch: Record<string, any> } }
    | { id: string; type: 'delete'; payload: { id: number } }
    | { id: string; type: 'reorder'; payload: { columnId: number; orderedIds: number[] } }
    | { id: string; type: 'move'; payload: { taskId: number; toColumnId: number; toIndex: number; targetOrderedIds: number[] } }

export default defineEventHandler(async (event) => {
    const body = await readBody<{ ops: BatchOp[] }>(event)
    const ops = Array.isArray(body?.ops) ? body.ops : []

    const results: Array<{ id: string; ok: boolean; data?: any; error?: string }> = []

    // Fan-out controlado; cada op é isolada (não derruba lote inteiro)
    for (const op of ops) {
        try {
            if (op.type === 'create') {
                const res = await proxyToLaravel(event, '/api/admin/tasks', { method: 'POST', body: op.payload })
                results.push({ id: op.id, ok: true, data: res })
                continue
            }
            if (op.type === 'update') {
                const { id, patch } = op.payload
                const res = await proxyToLaravel(event, `/api/admin/tasks/${id}`, { method: 'PUT', body: patch })
                results.push({ id: op.id, ok: true, data: res })
                continue
            }
            if (op.type === 'delete') {
                const { id } = op.payload
                let okData: any = null
                try {
                    okData = await proxyToLaravel(event, `/api/admin/tasks/${id}`, { method: 'DELETE' })
                } catch (e: any) {
                    const code = e?.statusCode || e?.response?.status
                    if (code !== 404) throw e // se 404, consideramos idempotente
                }
                results.push({ id: op.id, ok: true, data: okData })
                continue
            }
            if (op.type === 'reorder') {
                // Sem endpoint bulk no Laravel → PUT um a um
                const { orderedIds } = op.payload
                for (let i = 0; i < orderedIds.length; i++) {
                    const id = orderedIds[i]
                    await proxyToLaravel(event, `/api/admin/tasks/${id}`, { method: 'PUT', body: { order_position: i } })
                }
                results.push({ id: op.id, ok: true, data: { count: orderedIds.length } })
                continue
            }
            if (op.type === 'move') {
                const { taskId, toColumnId, toIndex, targetOrderedIds } = op.payload
                await proxyToLaravel(event, `/api/admin/tasks/${taskId}`, {
                    method: 'PUT',
                    body: { column_id: toColumnId, order_position: toIndex }
                })
                // reindex alvo
                for (let i = 0; i < targetOrderedIds.length; i++) {
                    const id = targetOrderedIds[i]
                    await proxyToLaravel(event, `/api/admin/tasks/${id}`, { method: 'PUT', body: { order_position: i } })
                }
                results.push({ id: op.id, ok: true, data: { moved: taskId } })
                continue
            }

            results.push({ id: op.id, ok: false, error: 'Unknown operation' })
        } catch (e: any) {
            results.push({ id: op.id, ok: false, error: e?.data?.message || e?.message || 'Batch op failed' })
        }
    }

    return { results }
})
