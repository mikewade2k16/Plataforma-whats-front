import { H3Event, readBody, getQuery, setResponseHeader } from 'h3'
import { getAuthConfig, readToken, writeToken, clearToken, isExpiringSoon } from './authSession'

function setAuthHeaders(event: H3Event, expiresIn?: number) {
  if (!expiresIn) return
  const expiresAt = new Date(Date.now() + expiresIn * 1000).toISOString()
  setResponseHeader(event, 'x-auth-refreshed', '1')
  setResponseHeader(event, 'x-auth-expires-in', String(expiresIn))
  setResponseHeader(event, 'x-auth-expires-at', expiresAt)
}

async function fetchLaravel(path: string, opts: any = {}, bearer?: string) {
  const { baseURL } = getAuthConfig()
  const url = new URL(path, baseURL).toString()
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ...(opts.headers || {}),
  }
  if (bearer) headers.Authorization = `Bearer ${bearer}`
  return await $fetch(url, { ...opts, headers })
}

export async function proxyToLaravel(event: H3Event, laravelPath: string, init?: any) {
  const method = (init?.method || event.node.req.method || 'GET').toUpperCase()
  const body = init?.body ?? (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method) ? await readBody(event) : undefined)
  const query = getQuery(event)
  const search = new URLSearchParams(query as Record<string, string>).toString()
  const fullPath = search ? `${laravelPath}?${search}` : laravelPath

  const stored = readToken(event)

  // refresh proativo
  if (stored && isExpiringSoon(stored)) {
    try {
      const refreshed: any = await fetchLaravel('/api/refresh', { method: 'POST' }, stored.access_token)
      if (refreshed?.access_token) {
        writeToken(event, refreshed)
        setAuthHeaders(event, Number(refreshed.expires_in ?? refreshed.expiresIn))
      }
    } catch { clearToken(event) }
  }

  const bearer = readToken(event)?.access_token

  // >>> se for chamar diretamente /api/refresh, escrevemos cookie e headers
  if (fullPath === '/api/refresh' && method === 'POST') {
    const refreshed: any = await fetchLaravel('/api/refresh', { method: 'POST' }, bearer)
    if (refreshed?.access_token) {
      writeToken(event, refreshed)
      setAuthHeaders(event, Number(refreshed.expires_in ?? refreshed.expiresIn))
      return refreshed
    }
  }

  try {
    return await fetchLaravel(fullPath, { method, body }, bearer || undefined)
  } catch (err: any) {
    const code = err?.status || err?.response?.status
    if ((code === 401 || code === 419) && bearer) {
      try {
        const refreshed: any = await fetchLaravel('/api/refresh', { method: 'POST' }, bearer)
        if (refreshed?.access_token) {
          writeToken(event, refreshed)
          setAuthHeaders(event, Number(refreshed.expires_in ?? refreshed.expiresIn))
          const newBearer = refreshed.access_token as string
          return await fetchLaravel(fullPath, { method, body }, newBearer)
        }
      } catch { clearToken(event) }
    }
    throw createError({
      statusCode: code || 500,
      statusMessage: err?.data?.message || err?.message || 'Proxy error',
      data: err?.data,
    })
  }
}
